# [NavComponent](./app/views/_navbar.html.erb)

i have created a view with an underscore to show that it is going to be partial- this means it can be rendered under other html files.
