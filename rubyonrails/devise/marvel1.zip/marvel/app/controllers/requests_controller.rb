class RequestsController < ApplicationController
  def create
  end
end
